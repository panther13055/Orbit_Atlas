# Orbit Atlas

Interactive editorial/science website about Earth's orbital environment and space debris.

## Run locally
```bash
npm install
npm run dev
```

## Build for Vercel
```bash
npm run build
```

Then push the repository to GitHub and import/link the repo in Vercel. Vercel will detect Vite automatically.

## Content sources
The site uses official ESA and ISRO report snapshots. Source links are included in the site. The numerical displays are intentionally labelled as report snapshots rather than live telemetry.
